﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Charlottesville.Controllers
{
    [Route("charlottesville/[controller]")]
    [ApiController]
    public class AdventController : ControllerBase
    {
        [HttpGet]
        public ActionResult<IEnumerable<int>> Get()
        {
            // This is how I tested. Input file from adventofcode included for reference.
            // Note that in a true production environment, I would have removed this, and the input file,
            // and would have put them in separate (offline) documentation. However, for this exercise,
            // I intentionally left this in as illustration.

            //string s = System.IO.File.ReadAllText(@"input.txt");    // 11846 and 6285 were right
            //(int, int) retval = Solver(s);
            //return new int[] { retval.Item1, retval.Item2 };

            return new int[] { -1 };        // User needs to provide some sort of input; return -1 error code
        }

        [HttpGet("{s}")]
        public int Get(string s)
        {
            return Solution(s);
        }

        [HttpPost]
        public int Post([FromBody] string s)
        {
            return Solution(s);
        }

        private int Solution(string s)
        {
            int retval;
            try
            {
                retval = Solver(s).Item1;
            }
            catch (Exception ex)
            {
                // something went horribly wrong; make this value negative, so we can detect a problem
                retval = (-1) * ex.HResult;
            }

            return retval;
        }

        // This solves both parts of day 9.
        private (int, int) Solver(string s)
        {
            char[] chars = s.ToCharArray();
            bool isGarbage = false; bool shouldIgnore = false;
            int score = 0, garbage = 0, depth = 0;

            foreach (char c in chars)
            {
                if (isGarbage)
                {
                    if (shouldIgnore)           
                    {
                        shouldIgnore = false;   // DON'T skip another character.
                        continue;               // stop HERE, don't fall through. Gah. 
                    }
                    if (c == '!')               // Only pay attention to this if we're in garbage!
                    {
                        shouldIgnore = true;    // Skip the next character
                        continue;               // stop here to properly calculate the garbage for part two.
                    }
                    if (c != '>') garbage++;    // ...increment garbage score (part two only)
                    if (c == '>') isGarbage = false;    // We're no longer in a garbage statement.
                    continue;
                }
                else
                {
                    if (c == '<') isGarbage = true;     // Now entering a garbage statement. Note that we don't leave until we hit an unskipped > in the garbage zone, above.
                    if (c == '{') depth++;              // Nesting depth increment
                    if (c == '}') score += depth--;     // Closing a scoring statement; add score, decrement depth (this is important!)
                    continue;
                }
            }

            return (score, garbage);
        }

    }
}
